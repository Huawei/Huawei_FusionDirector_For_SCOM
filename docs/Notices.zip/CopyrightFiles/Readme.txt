NLog - Advanced .NET Logging 4.5.11(05833BST)Copyright信息为空，请手动添加. 
NSIS NsProcess plugin 1.6(05832SEL)Copyright信息为空，请手动添加. 

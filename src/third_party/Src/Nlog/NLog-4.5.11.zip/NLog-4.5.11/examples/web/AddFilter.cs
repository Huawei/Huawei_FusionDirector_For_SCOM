static void Main(string[] args)
{
    FilterFactory.AddFilter("MyFirst", typeof(MyNamespace.MyFirstFilter));

    // start logging here
}
